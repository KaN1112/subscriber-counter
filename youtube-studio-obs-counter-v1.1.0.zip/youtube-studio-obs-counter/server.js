'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const HOST = '127.0.0.1';
const PORT = 4751;
const ROOT = __dirname;
const USER_DATA = process.platform === 'win32' && process.env.APPDATA
  ? process.env.APPDATA
  : path.join(os.homedir(), '.config');
const SETTINGS_PATH = path.join(USER_DATA, 'youtube-studio-obs-counter', 'settings.json');
const DEFAULTS = {
  mode: 'studio',
  channelId: '',
  goal: 1000,
  apiKey: '',
  pollSeconds: 30,
  fontSize: 64,
  textColor: '#ffffff',
  outlineColor: '#000000',
  outlineWidth: 2
};

function loadSettings() {
  try {
    const stored = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8'));
    return { ...DEFAULTS, ...stored };
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('設定読み込みエラー:', error.message);
    return { ...DEFAULTS };
  }
}

let settings = loadSettings();
let snapshot = { count: null, updatedAt: null, source: null, error: null };
let polling = false;
let pollAt = 0;

function saveSettings() {
  fs.mkdirSync(path.dirname(SETTINGS_PATH), { recursive: true, mode: 0o700 });
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2) + '\n', { mode: 0o600 });
}

function sendJson(res, status, data, origin) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  if (origin) res.setHeader('Access-Control-Allow-Origin', origin);
  res.end(JSON.stringify(data));
}

function sendFile(res, name, type) {
  res.statusCode = 200;
  res.setHeader('Content-Type', type);
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.end(fs.readFileSync(path.join(ROOT, name)));
}

function getPublicSettings() {
  const { apiKey, ...publicFields } = settings;
  return { ...publicFields, hasApiKey: Boolean(apiKey) };
}

function isHexColor(value) {
  return typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value);
}

function isChannelId(value) {
  return typeof value === 'string' && /^UC[A-Za-z0-9_-]{22}$/.test(value);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 16384) {
        reject(new Error('データが大きすぎます'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(raw)); }
      catch { reject(new Error('JSONの形式が正しくありません')); }
    });
    req.on('error', reject);
  });
}

function studioOrigin(origin) {
  return typeof origin === 'string' && /^chrome-extension:\/\/[a-p]{32}$/.test(origin);
}

function adminOriginAllowed(origin) {
  return !origin || origin === `http://${HOST}:${PORT}`;
}

async function pollYouTube() {
  if (polling || settings.mode !== 'api') return;
  if (!settings.apiKey || !isChannelId(settings.channelId)) {
    snapshot.error = 'APIキーとチャンネルIDを設定してください';
    return;
  }
  polling = true;
  const channelId = settings.channelId;
  const apiKey = settings.apiKey;
  try {
    const url = new URL('https://www.googleapis.com/youtube/v3/channels');
    url.searchParams.set('part', 'statistics');
    url.searchParams.set('id', channelId);
    url.searchParams.set('key', apiKey);
    const response = await fetch(url, { signal: AbortSignal.timeout(12000) });
    const json = await response.json();
    if (!response.ok) {
      throw new Error(json?.error?.message || `YouTube API HTTP ${response.status}`);
    }
    const value = Number(json?.items?.[0]?.statistics?.subscriberCount);
    if (!Number.isSafeInteger(value) || value < 0) throw new Error('登録者数を取得できませんでした');
    if (settings.mode === 'api' && settings.channelId === channelId) {
      snapshot = { count: value, updatedAt: Date.now(), source: 'api', error: null };
    }
  } catch (error) {
    if (settings.mode === 'api') snapshot.error = error.message;
    console.error('API更新エラー:', error.message);
  } finally {
    polling = false;
  }
}

setInterval(() => {
  if (settings.mode !== 'api') return;
  if (Date.now() - pollAt < settings.pollSeconds * 1000) return;
  pollAt = Date.now();
  pollYouTube();
}, 1000);

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  const extensionOrigin = studioOrigin(origin);
  const requestUrl = new URL(req.url, `http://${HOST}:${PORT}`);
  const url = requestUrl.pathname;
  if (req.method === 'OPTIONS' && url === '/api/studio-count' && extensionOrigin) {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, X-OBS-Subscriber-Bridge',
      'Access-Control-Max-Age': '600'
    });
    res.end();
    return;
  }
  try {
    if (req.method === 'GET' && url === '/') return sendFile(res, 'settings.html', 'text/html; charset=utf-8');
    if (req.method === 'GET' && url === '/overlay') return sendFile(res, 'overlay.html', 'text/html; charset=utf-8');
    if (req.method === 'GET' && url === '/api/state') {
      return sendJson(res, 200, { ...snapshot, goal: settings.goal, mode: settings.mode,
        fontSize: settings.fontSize, textColor: settings.textColor,
        outlineColor: settings.outlineColor, outlineWidth: settings.outlineWidth });
    }
    if (req.method === 'GET' && url === '/api/config') return sendJson(res, 200, getPublicSettings());
    if (req.method === 'POST' && url === '/api/config') {
      if (!adminOriginAllowed(origin)) return sendJson(res, 403, { error: 'アクセスが許可されていません' });
      const data = await readBody(req);
      const { mode, channelId, goal, apiKey, pollSeconds, fontSize, textColor, outlineColor, outlineWidth } = data;
      if (!['studio', 'api'].includes(mode)) throw new Error('取得方法が正しくありません');
      if (channelId !== '' && !isChannelId(channelId)) throw new Error('チャンネルIDが正しくありません');
      if (mode === 'api' && !isChannelId(channelId)) throw new Error('APIモードではチャンネルIDが必要です');
      if (!Number.isSafeInteger(goal) || goal < 1 || goal > 1e10) throw new Error('目標人数を確認してください');
      if (!Number.isInteger(pollSeconds) || pollSeconds < 15 || pollSeconds > 600) throw new Error('更新間隔は15〜600秒にしてください');
      if (!Number.isInteger(fontSize) || fontSize < 24 || fontSize > 100) throw new Error('文字サイズは24〜100です');
      if (!isHexColor(textColor) || !isHexColor(outlineColor)) throw new Error('文字色・縁取り色を確認してください');
      if (!Number.isInteger(outlineWidth) || outlineWidth < 0 || outlineWidth > 8) throw new Error('縁取りの太さは0〜8です');
      const previousMode = settings.mode;
      const previousChannel = settings.channelId;
      settings = { ...settings, mode, channelId, goal, pollSeconds, fontSize, textColor, outlineColor, outlineWidth };
      if (typeof apiKey === 'string' && apiKey.trim()) settings.apiKey = apiKey.trim();
      if (data.clearApiKey === true) settings.apiKey = '';
      saveSettings();
      if (previousMode !== mode || previousChannel !== channelId) {
        snapshot = { count: null, updatedAt: null, source: null, error: null };
      }
      if (mode === 'api') {
        pollAt = Date.now();
        void pollYouTube();
      }
      return sendJson(res, 200, { ok: true, settings: getPublicSettings() });
    }
    if (req.method === 'POST' && url === '/api/studio-count') {
      if (!extensionOrigin || req.headers['x-obs-subscriber-bridge'] !== '1') {
        return sendJson(res, 403, { error: 'Chrome拡張機能から送信してください' }, extensionOrigin ? origin : null);
      }
      const data = await readBody(req);
      if (settings.mode !== 'studio') return sendJson(res, 409, { error: '取得方法をYouTube Studioにしてください' }, origin);
      if (!isChannelId(data.channelId)) {
        return sendJson(res, 400, { error: 'StudioのチャンネルIDが正しくありません' }, origin);
      }
      if (!Number.isSafeInteger(data.count) || data.count < 0 || data.count > 1e10) {
        return sendJson(res, 400, { error: '登録者数が正しくありません' }, origin);
      }
      if (!settings.channelId) {
        settings.channelId = data.channelId;
        saveSettings();
      }
      if (data.channelId !== settings.channelId) {
        return sendJson(res, 409, { error: '別のチャンネルです。設定画面でチャンネルIDを空欄にして再連携してください' }, origin);
      }
      snapshot = { count: data.count, updatedAt: Date.now(), source: 'studio', error: null };
      return sendJson(res, 200, { ok: true }, origin);
    }
    return sendJson(res, 404, { error: 'ページが見つかりません' });
  } catch (error) {
    console.error('エラー:', error.message);
    return sendJson(res, 400, { error: error.message }, extensionOrigin ? origin : null);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`\nYouTube OBS Subscriber Counter 起動中`);
  console.log(`設定画面: http://${HOST}:${PORT}/`);
  console.log(`OBS用URL: http://${HOST}:${PORT}/overlay`);
  if (settings.mode === 'api') { pollAt = Date.now(); void pollYouTube(); }
});
