'use strict';

const BRIDGE = 'http://127.0.0.1:4751/api/studio-count';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'COUNT_UPDATE') return false;
  if (!sender.tab || !sender.url?.startsWith('https://studio.youtube.com/')) {
    sendResponse({ ok: false, error: 'YouTube Studio以外からは送信できません' });
    return false;
  }
  const count = Number(message.count);
  if (!Number.isSafeInteger(count) || count < 0 || count > 10000000000) {
    sendResponse({ ok: false, error: '登録者数が不正です' });
    return false;
  }
  const channelId = String(message.channelId || '');
  if (!/^UC[A-Za-z0-9_-]{22}$/.test(channelId)) {
    sendResponse({ ok: false, error: 'チャンネルIDが見つかりません' });
    return false;
  }
  (async () => {
    try {
      const response = await fetch(BRIDGE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-OBS-Subscriber-Bridge': '1' },
        body: JSON.stringify({ count, channelId }),
        signal: AbortSignal.timeout(4500)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'OBSへ送信できませんでした');
      await chrome.storage.local.set({ bridgeLast: { ok: true, count, updatedAt: Date.now() } });
      sendResponse({ ok: true });
    } catch (error) {
      await chrome.storage.local.set({ bridgeLast: { ok: false, error: error.message, updatedAt: Date.now() } });
      sendResponse({ ok: false, error: error.message });
    }
  })();
  return true;
});
