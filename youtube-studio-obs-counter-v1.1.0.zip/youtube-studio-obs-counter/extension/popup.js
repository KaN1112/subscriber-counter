'use strict';

const status = document.getElementById('status');
const pick = document.getElementById('pick');
let studioTab = null;

async function update() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  studioTab = tabs[0];
  if (!studioTab?.url?.startsWith('https://studio.youtube.com/')) {
    pick.disabled = true;
    status.textContent = 'YouTube Studioのページを開いてから押してください。';
    return;
  }
  try {
    const state = await chrome.tabs.sendMessage(studioTab.id, { type: 'STATUS' });
    const saved = await chrome.storage.local.get('bridgeLast');
    const value = state?.currentValue;
    if (Number.isInteger(value)) {
      status.textContent = '選択中の人数: ' + value.toLocaleString('en-US') + ' 人';
    } else if (state?.hasTarget && state?.pageMatches) {
      status.textContent = '登録者数の表示待ちです。変更された場合は再選択してください。';
    } else {
      status.textContent = '登録者数はまだ選択されていません。';
    }
    if (saved.bridgeLast && Date.now() - saved.bridgeLast.updatedAt < 30000) {
      status.textContent += '\n' + (saved.bridgeLast.ok ? ' / OBSへ送信済み' : ' / 接続エラー: ' + saved.bridgeLast.error);
    }
  } catch {
    status.textContent = 'Studioページを再読み込みしてから再試行してください。';
  }
}

pick.addEventListener('click', async () => {
  if (!studioTab) return;
  try {
    await chrome.tabs.sendMessage(studioTab.id, { type: 'START_SELECTION' });
    window.close();
  } catch {
    status.textContent = 'Studioページを再読み込みしてください。';
  }
});

update();
