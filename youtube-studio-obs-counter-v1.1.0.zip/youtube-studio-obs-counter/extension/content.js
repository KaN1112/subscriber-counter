'use strict';

(() => {
  let selectedSelector = null;
  let selectedUrl = null;
  let selectedElement = null;
  let lastValue = null;
  let lastSent = 0;
  let selectionMode = false;
  let highlighted = null;
  let banner = null;
  let timer = null;

  function readNumber(element) {
    if (!(element instanceof HTMLElement || element instanceof SVGElement)) return null;
    const raw = (element.innerText || element.textContent || '').trim().replace(/[\u200e\u200f]/g, '');
    if (!/^(?:\d{1,3}(?:[,\s\u00a0\u202f]\d{3})+|\d{1,11})$/.test(raw)) return null;
    const digits = raw.replace(/[,\s\u00a0\u202f]/g, '');
    const value = Number(digits);
    return Number.isSafeInteger(value) && value >= 0 ? value : null;
  }

  function candidate(start) {
    let element = start instanceof Element ? start : start?.parentElement;
    for (let i = 0; element && i < 5; i++, element = element.parentElement) {
      if (readNumber(element) !== null) return element;
    }
    return null;
  }

  function makeSelector(element) {
    const selectors = [];
    for (let node = element; node && node !== document.documentElement; node = node.parentElement) {
      if (node.id && !/^\d/.test(node.id)) {
        const selector = '#' + CSS.escape(node.id);
        if (document.querySelectorAll(selector).length === 1) {
          selectors.unshift(selector);
          break;
        }
      }
      const tag = node.tagName.toLowerCase();
      const parent = node.parentElement;
      if (!parent) break;
      const siblings = Array.from(parent.children).filter(child => child.tagName === node.tagName);
      const index = siblings.indexOf(node) + 1;
      selectors.unshift(tag + ':nth-of-type(' + index + ')');
    }
    return selectors.join(' > ');
  }

  function channelId() {
    const match = location.pathname.match(/\/channel\/(UC[A-Za-z0-9_-]{22})(?:\/|$)/);
    return match?.[1] || null;
  }

  function urlKey() {
    return location.origin + location.pathname;
  }

  function showBanner(message) {
    if (!banner) {
      banner = document.createElement('div');
      banner.style.cssText = 'position:fixed;right:18px;top:18px;z-index:2147483647;padding:13px 16px;border-radius:4px;background:#121923;color:#fff;font:600 14px/1.6 Arial,sans-serif;box-shadow:0 4px 14px #0003;max-width:340px;pointer-events:none;white-space:pre-line';
      document.documentElement.appendChild(banner);
    }
    banner.textContent = message;
  }

  function clearHighlight() {
    if (highlighted) {
      highlighted.style.outline = highlighted.dataset.obsPreviousOutline || '';
      delete highlighted.dataset.obsPreviousOutline;
      highlighted = null;
    }
  }

  function highlight(element) {
    if (highlighted === element) return;
    clearHighlight();
    if (element) {
      highlighted = element;
      highlighted.dataset.obsPreviousOutline = highlighted.style.outline;
      highlighted.style.outline = '3px solid #00b5ff';
    }
  }

  function mouseMove(event) {
    highlight(candidate(event.target));
  }

  async function choose(event) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    const element = candidate(event.target);
    if (!element) {
      showBanner('数字が選択できません。\n登録者数の数字そのものをクリックしてください。');
      return;
    }
    const channel = channelId();
    if (!channel) {
      showBanner('チャンネルIDをURLから確認できません。\nStudioのチャンネルページを開いてください。');
      return;
    }
    selectedSelector = makeSelector(element);
    selectedUrl = urlKey();
    selectedElement = element;
    lastSent = 0;
    lastValue = null;
    await chrome.storage.local.set({ studioTarget: { selector: selectedSelector, url: selectedUrl } });
    stopSelection();
    showBanner('登録者数 ' + readNumber(element).toLocaleString('en-US') + ' 人を選択しました。\nOBSへ送信します。');
    setTimeout(() => { banner?.remove(); banner = null; }, 3000);
    void tick();
  }

  function stopSelection() {
    selectionMode = false;
    document.removeEventListener('mousemove', mouseMove, true);
    document.removeEventListener('click', choose, true);
    clearHighlight();
    document.body.style.cursor = '';
  }

  function startSelection() {
    stopSelection();
    selectionMode = true;
    showBanner('OBS連携：登録者数の数字をクリック\n選択を中止する場合は Esc を押してください');
    document.body.style.cursor = 'crosshair';
    document.addEventListener('mousemove', mouseMove, true);
    document.addEventListener('click', choose, true);
  }

  document.addEventListener('keydown', event => {
    if (selectionMode && event.key === 'Escape') {
      stopSelection();
      banner?.remove();
      banner = null;
    }
  }, true);

  async function tick() {
    if (selectionMode || !selectedSelector || selectedUrl !== urlKey()) return;
    if (!selectedElement?.isConnected) {
      try { selectedElement = document.querySelector(selectedSelector); } catch { selectedElement = null; }
    }
    if (!selectedElement) return;
    const count = readNumber(selectedElement);
    if (count === null) return;
    const now = Date.now();
    if (count === lastValue && now - lastSent < 10000) return;
    lastValue = count;
    lastSent = now;
    try {
      await chrome.runtime.sendMessage({ type: 'COUNT_UPDATE', count, channelId: channelId() });
    } catch {
      // ページを移動した直後は次の周期で再送します。
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'START_SELECTION') {
      startSelection();
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === 'STATUS') {
      sendResponse({ ok: true, hasTarget: Boolean(selectedSelector), pageMatches: selectedUrl === urlKey(),
        currentValue: readNumber(selectedElement), channelId: channelId() });
      return false;
    }
    return false;
  });

  chrome.storage.local.get('studioTarget', result => {
    if (!result.studioTarget) return;
    selectedSelector = result.studioTarget.selector;
    selectedUrl = result.studioTarget.url;
    void tick();
  });
  timer = setInterval(tick, 1000);
  const observer = new MutationObserver(() => {
    if (!selectedElement?.isConnected) selectedElement = null;
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('pagehide', () => {
    clearInterval(timer);
    observer.disconnect();
  });
})();
