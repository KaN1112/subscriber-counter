@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
    echo Node.js is not installed. Please install Node.js 18 or later.
    echo https://nodejs.org/
    pause
    exit /b 1
)
echo.
echo YouTube Studio OBS Subscriber Counter
echo Set up at: http://127.0.0.1:4751/
echo Keep this window open while streaming.
echo.
node server.js
pause
